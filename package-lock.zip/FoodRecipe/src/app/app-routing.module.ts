import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SearchComponent } from './search/search.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { BreadrecipeComponent } from './breadrecipe/breadrecipe.component';
import { BlueberrybreadComponent } from './blueberrybread/blueberrybread.component';
import { EggreceipeComponent } from './eggreceipe/eggreceipe.component';
import { ScrambledeggComponent } from './scrambledegg/scrambledegg.component';
import { NonvegreceipeComponent } from './nonvegreceipe/nonvegreceipe.component';
import { ChickenwingsComponent } from './chickenwings/chickenwings.component';
import { VegreceipeComponent } from './vegreceipe/vegreceipe.component';
import { VegetablecurryComponent } from './vegetablecurry/vegetablecurry.component';

const routes: Routes = [{ path: 'about',pathMatch: 'full', component:  AboutComponent},
{path: 'login',pathMatch: 'full', component:  LoginComponent},
{path: 'signup',pathMatch: 'full', component:  SignupComponent},
{path: 'search',pathMatch: 'full', component:  SearchComponent},
{path: 'admin',pathMatch: 'full', component:  AdminComponent},
{path: 'user',pathMatch: 'full', component:  UserComponent},
{path: 'home',pathMatch: 'full', component:  HomeComponent},
{path: 'breadrecipe',pathMatch: 'full', component:  BreadrecipeComponent},
{path: 'eggreceipe',pathMatch: 'full', component:  EggreceipeComponent},
{path: 'blueberrybread',pathMatch: 'full', component:  BlueberrybreadComponent},
{path: 'scrambledegg',pathMatch: 'full', component:  ScrambledeggComponent},
{path: 'nonvegreceipe',pathMatch: 'full', component:  NonvegreceipeComponent},
{path: 'chickenwings',pathMatch: 'full', component:  ChickenwingsComponent},
{path: 'vegreceipe',pathMatch: 'full', component:  VegreceipeComponent},
{path: 'vegetablecurry',pathMatch: 'full', component:  VegetablecurryComponent},

{path: '',redirectTo: 'HomeComponent',pathMatch: 'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
