import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scrambledegg',
  templateUrl: './scrambledegg.component.html',
  styleUrls: ['./scrambledegg.component.css']
})
export class ScrambledeggComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
