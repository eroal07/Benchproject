import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrambledeggComponent } from './scrambledegg.component';

describe('ScrambledeggComponent', () => {
  let component: ScrambledeggComponent;
  let fixture: ComponentFixture<ScrambledeggComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScrambledeggComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrambledeggComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
