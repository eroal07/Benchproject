import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BreadrecipeComponent } from './breadrecipe.component';

describe('BreadrecipeComponent', () => {
  let component: BreadrecipeComponent;
  let fixture: ComponentFixture<BreadrecipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BreadrecipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadrecipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
