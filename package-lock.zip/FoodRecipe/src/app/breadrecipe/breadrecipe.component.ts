import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadrecipe',
  templateUrl: './breadrecipe.component.html',
  styleUrls: ['./breadrecipe.component.css']
})
export class BreadrecipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
