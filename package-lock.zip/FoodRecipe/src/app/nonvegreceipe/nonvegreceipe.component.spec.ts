import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NonvegreceipeComponent } from './nonvegreceipe.component';

describe('NonvegreceipeComponent', () => {
  let component: NonvegreceipeComponent;
  let fixture: ComponentFixture<NonvegreceipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NonvegreceipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NonvegreceipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
