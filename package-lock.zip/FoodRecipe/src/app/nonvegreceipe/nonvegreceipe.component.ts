import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nonvegreceipe',
  templateUrl: './nonvegreceipe.component.html',
  styleUrls: ['./nonvegreceipe.component.css']
})
export class NonvegreceipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
