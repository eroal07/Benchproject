import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chickenwings',
  templateUrl: './chickenwings.component.html',
  styleUrls: ['./chickenwings.component.css']
})
export class ChickenwingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
