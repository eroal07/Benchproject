import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegreceipe',
  templateUrl: './vegreceipe.component.html',
  styleUrls: ['./vegreceipe.component.css']
})
export class VegreceipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
