import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eggreceipe',
  templateUrl: './eggreceipe.component.html',
  styleUrls: ['./eggreceipe.component.css']
})
export class EggreceipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
