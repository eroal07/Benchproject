import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EggreceipeComponent } from './eggreceipe.component';

describe('EggreceipeComponent', () => {
  let component: EggreceipeComponent;
  let fixture: ComponentFixture<EggreceipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EggreceipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EggreceipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
