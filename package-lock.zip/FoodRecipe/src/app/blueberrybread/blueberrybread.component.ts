import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blueberrybread',
  templateUrl: './blueberrybread.component.html',
  styleUrls: ['./blueberrybread.component.css']
})
export class BlueberrybreadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
