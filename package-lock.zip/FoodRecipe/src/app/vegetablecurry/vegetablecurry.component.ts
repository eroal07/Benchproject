import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegetablecurry',
  templateUrl: './vegetablecurry.component.html',
  styleUrls: ['./vegetablecurry.component.css']
})
export class VegetablecurryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
