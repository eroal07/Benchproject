import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VegetablecurryComponent } from './vegetablecurry.component';

describe('VegetablecurryComponent', () => {
  let component: VegetablecurryComponent;
  let fixture: ComponentFixture<VegetablecurryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VegetablecurryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VegetablecurryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
